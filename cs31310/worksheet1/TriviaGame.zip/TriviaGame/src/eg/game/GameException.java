package eg.game;

public class GameException extends Exception {

	public GameException(String message) { 
		super(message); 
	}
}
